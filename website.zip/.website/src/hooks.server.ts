import { htmlLang } from '$lib/i18n';
import { localeFromPath } from '$lib/routing';
import type { Handle } from '@sveltejs/kit';

/**
 * Permanent redirects for URLs that used to exist.
 *
 * nett-med.ca was a Blogger site before this one, and Google still has some of
 * its pages indexed (`/2023/11/….html`, `/search/label`). They now 404, which
 * discards whatever ranking they had and shows searchers a dead end. A 301
 * passes them to the closest current page instead.
 *
 * The floor stripping and waxing service was removed because Nett-Med does
 * not offer it; its old URLs go to the services list rather than to a
 * different service, so nobody lands on a page that implies otherwise.
 */
const exact: Record<string, string> = {
	'/services/decapage-cirage-planchers': '/services',
	'/en/services/floor-stripping-waxing': '/en/services',
	'/search': '/blogue',
	'/feeds/posts/default': '/blogue'
};

const patterns: [RegExp, string][] = [
	// Blogger post URLs: /2023/11/some-title.html
	[/^\/\d{4}\/\d{2}\/[^/]+\.html$/, '/'],
	// Blogger label and archive listings
	[/^\/search\/label(\/.*)?$/, '/blogue'],
	[/^\/\d{4}(\/\d{2})?\/?$/, '/blogue'],
	// Blogger static pages: /p/contact.html, /p/services.html, …
	[/^\/p\/contact[^/]*\.html$/, '/contact'],
	[/^\/p\/service[^/]*\.html$/, '/services'],
	[/^\/p\/(galerie|gallery|photo)[^/]*\.html$/, '/realisations'],
	[/^\/p\/[^/]+\.html$/, '/']
];

function legacyTarget(pathname: string): string | null {
	if (exact[pathname]) return exact[pathname];
	for (const [pattern, target] of patterns) {
		if (pattern.test(pathname)) return target;
	}
	return null;
}

/**
 * Also fills the %lang% placeholder in app.html.
 *
 * <html lang> has to be correct per page, not per site: a French page served
 * as lang="en" gets read by screen readers with the wrong pronunciation rules
 * and muddies the language signal for search engines on a bilingual domain.
 */
export const handle: Handle = async ({ event, resolve }) => {
	const target = legacyTarget(event.url.pathname);
	if (target) {
		return new Response(null, { status: 301, headers: { location: target } });
	}

	const lang = htmlLang[localeFromPath(event.url.pathname)];

	return resolve(event, {
		transformPageChunk: ({ html }) => html.replace('%lang%', lang)
	});
};
