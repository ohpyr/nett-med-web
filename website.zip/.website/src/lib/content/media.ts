import type { Locale } from '$lib/i18n';

/*
  Every job-site photo, imported once and shared by the gallery, the home hero
  and the service pages.

  Imported with `?enhanced` — never referenced by path string. Vite only
  rewrites URLs for imported files, so a bare 'src/lib/assets/...' string ships
  as-is and 404s. The `&w=` list makes enhanced-img emit `w` descriptors so
  `sizes` is honoured; it must match the ambient declaration in
  src/enhanced-img.d.ts.

  Captions describe what is visible, not what was done. The stone lobbies are
  washed and maintained, not stripped or waxed — Nett-Med does not offer floor
  stripping, and a caption must never imply it does.
*/

import hallGranitIncrustation from '$lib/assets/work/hall-granit-incrustation.jpg?enhanced&w=1200;800;400';
import hallGranitPortes from '$lib/assets/work/hall-granit-portes.jpg?enhanced&w=1200;800;400';
import hallGranitLaiton from '$lib/assets/work/hall-granit-laiton.jpg?enhanced&w=1200;800;400';
import hallTravertinEntree from '$lib/assets/work/hall-travertin-entree.jpg?enhanced&w=1200;800;400';
import hallTravertinVue from '$lib/assets/work/hall-travertin-vue.jpg?enhanced&w=1200;800;400';
import entreeCommerciale from '$lib/assets/work/entree-immeuble-commercial.jpg?enhanced&w=1200;800;400';
import corridorResidentiel from '$lib/assets/work/im-res.jpg?enhanced&w=1200;800;400';
import corridorClinique from '$lib/assets/work/ap2.jpg?enhanced&w=1200;800;400';
import restaurantBois from '$lib/assets/work/resto.jpg?enhanced&w=1200;800;400';
import restaurantBlanc from '$lib/assets/work/restaurant-salle-tuile-blanche.jpg?enhanced&w=1200;800;400';
import salonCoiffure from '$lib/assets/work/salon-coiffure-plancher.jpg?enhanced&w=1200;800;400';
import cuisineReno from '$lib/assets/work/ms.jpg?enhanced&w=1200;800;400';
import cuisineResidentielle from '$lib/assets/work/cuisine-residentielle.jpg?enhanced&w=1200;800;400';
import appartement from '$lib/assets/work/appartement-salon-bois-franc.jpg?enhanced&w=1200;800;400';
import logementVide from '$lib/assets/work/logement-vide-bois-franc.jpg?enhanced&w=1200;800;400';

export type EnhancedImage = typeof hallGranitIncrustation;

export interface Photo {
	src: EnhancedImage;
	alt: Record<Locale, string>;
}

export const photos = {
	hallGranitIncrustation: {
		src: hallGranitIncrustation,
		alt: {
			fr: 'Hall d’entrée d’immeuble, plancher de granit lustré avec motif incrusté en losange noir',
			en: 'Building lobby with a gleaming granite floor and a black diamond inlay'
		}
	},
	hallGranitPortes: {
		src: hallGranitPortes,
		alt: {
			fr: 'Portes vitrées d’un hall d’immeuble ouvertes sur la rue, plancher de granit propre et brillant',
			en: 'Glass lobby doors open to the street over a clean, glossy granite floor'
		}
	},
	hallGranitLaiton: {
		src: hallGranitLaiton,
		alt: {
			fr: 'Vestibule d’immeuble avec porte vitrée à cadre de laiton et plancher de granit propre',
			en: 'Building vestibule with a brass-framed glass door and a clean granite floor'
		}
	},
	hallTravertinEntree: {
		src: hallTravertinEntree,
		alt: {
			fr: 'Hall d’immeuble résidentiel, plancher de travertin lavé et entrée vitrée',
			en: 'Residential building lobby with a washed travertine floor and glass entrance'
		}
	},
	hallTravertinVue: {
		src: hallTravertinVue,
		alt: {
			fr: 'Plancher de travertin brillant dans le hall d’un immeuble, vu vers les portes d’entrée',
			en: 'Shining travertine floor in a building lobby, looking toward the entrance doors'
		}
	},
	entreeCommerciale: {
		src: entreeCommerciale,
		alt: {
			fr: 'Entrée d’un immeuble commercial, tuile grise lavée, murs de bois et plante en pot',
			en: 'Commercial building entrance with washed grey tile, wood walls and a potted plant'
		}
	},
	corridorResidentiel: {
		src: corridorResidentiel,
		alt: {
			fr: 'Corridor d’immeuble résidentiel, plancher de terrazzo lavé et tapis d’entrée devant les portes',
			en: 'Residential building corridor with a washed terrazzo floor and mats outside the doors'
		}
	},
	corridorClinique: {
		src: corridorClinique,
		alt: {
			fr: 'Corridor de clinique avec salles de traitement numérotées et cloisons vitrées',
			en: 'Clinic corridor with numbered treatment rooms and glass partitions'
		}
	},
	restaurantBois: {
		src: restaurantBois,
		alt: {
			fr: 'Salle à manger de restaurant remise en ordre après la fermeture, plancher imitation bois',
			en: 'Restaurant dining room reset after closing, wood-look tile floor'
		}
	},
	restaurantBlanc: {
		src: restaurantBlanc,
		alt: {
			fr: 'Section d’un restaurant avec plancher de tuile blanche propre et tables dressées',
			en: 'Restaurant section with a clean white tile floor and set tables'
		}
	},
	salonCoiffure: {
		src: salonCoiffure,
		alt: {
			fr: 'Salon de coiffure, plancher blanc lustré et postes de coiffure alignés',
			en: 'Hair salon with a glossy white floor and a row of styling stations'
		}
	},
	cuisineReno: {
		src: cuisineReno,
		alt: {
			fr: 'Cuisine neuve livrée prête à occuper, îlot de quartz dégagé et armoires blanches',
			en: 'New kitchen delivered move-in ready, cleared quartz island and white cabinets'
		}
	},
	cuisineResidentielle: {
		src: cuisineResidentielle,
		alt: {
			fr: 'Cuisine résidentielle nettoyée, comptoirs dégagés et électroménagers en acier inoxydable',
			en: 'Cleaned residential kitchen, clear counters and stainless steel appliances'
		}
	},
	appartement: {
		src: appartement,
		alt: {
			fr: 'Salon d’appartement montréalais, plancher de bois franc poli et mur de brique',
			en: 'Montreal apartment living room with polished hardwood and an exposed brick wall'
		}
	},
	logementVide: {
		src: logementVide,
		alt: {
			fr: 'Logement vide nettoyé avant l’emménagement, plancher de bois franc brillant',
			en: 'Empty unit cleaned before move-in, shining hardwood floor'
		}
	}
} satisfies Record<string, Photo>;

/** The one video. Served from static/, not processed by enhanced-img. */
export const restaurantVideo = {
	webm: '/video/restaurant-depoussierage-plafond.webm',
	mp4: '/video/restaurant-depoussierage-plafond.mp4',
	poster: '/video/restaurant-depoussierage-plafond.jpg',
	width: 268,
	height: 480,
	label: {
		fr: 'Dépoussiérage du plafond et des luminaires d’un restaurant, après la fermeture',
		en: 'Dusting a restaurant ceiling and light fixtures after closing'
	}
};

/**
 * One representative photo per service page. Services with no matching
 * photograph stay text-only rather than borrowing an unrelated image — a
 * garage page illustrated with a restaurant would undercut the whole page.
 */
export const servicePhoto: Partial<Record<string, Photo>> = {
	commercial: photos.entreeCommerciale,
	immeubles: photos.hallTravertinEntree,
	restaurants: photos.restaurantBois,
	commerces: photos.salonCoiffure,
	cliniques: photos.corridorClinique,
	'apres-construction': photos.cuisineReno,
	residentiel: photos.cuisineResidentielle,
	'grand-menage': photos.appartement,
	demenagement: photos.logementVide
};
