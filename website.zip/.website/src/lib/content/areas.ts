import type { Locale } from '$lib/i18n';
import { photos, type Photo } from './media';

/*
  Service area, by region.

  Three regional pages rather than one page per municipality. A page per town
  — "entretien ménager Brossard", "… Boucherville", "… Candiac" — is the
  classic way a young local site gets filtered as thin, near-duplicate content.
  Three pages, each with its own municipality list and its own framing, target
  the regional searches ("entretien ménager Rive-Sud", "… Laval") without that
  risk, and the full list on each page still matches town-level searches.

  The list was cleaned from the one supplied: typos fixed, duplicates removed,
  run-together entries split, and the Vaudreuil-Soulanges towns moved out of
  the Rive-Sud, where they had been misfiled. Municipality names stay in
  French in both locales — they are proper nouns.

  Nothing here claims past work in a given town. The only location-specific
  fact used is the office address, and the only photo is the one job whose
  borough is actually known.
*/

export interface AreaGroup {
	label: Record<Locale, string>;
	places: string[];
}

interface RegionCopy {
	slug: string;
	name: string;
	h1: string;
	metaTitle: string;
	metaDescription: string;
	lede: string;
	body: string[];
}

export interface Region {
	id: 'montreal' | 'rive-nord' | 'rive-sud';
	/** Headline municipalities, used in the schema alongside every listed place. */
	primary: string[];
	groups: AreaGroup[];
	/** Service ids worth featuring for this region. */
	services: string[];
	photo?: Photo;
	fr: RegionCopy;
	en: RegionCopy;
}

export const regions: Region[] = [
	{
		id: 'montreal',
		primary: ['Montréal'],
		services: ['immeubles', 'bureaux', 'garage', 'commercial'],
		photo: photos.corridorResidentiel,
		groups: [
			{
				label: { fr: 'Centre', en: 'Downtown and centre' },
				places: [
					'Centre-ville',
					'Vieux-Montréal',
					'Plateau-Mont-Royal',
					'Outremont',
					'Westmount',
					'Côte-des-Neiges',
					'Notre-Dame-de-Grâce',
					'Mont-Royal',
					'Hampstead',
					'Côte-Saint-Luc',
					'Montréal-Ouest'
				]
			},
			{
				label: { fr: 'Est', en: 'East' },
				places: [
					'Rosemont',
					'Petite-Patrie',
					'Saint-Léonard',
					'Anjou',
					'Montréal-Est',
					'Pointe-aux-Trembles',
					'Rivière-des-Prairies'
				]
			},
			{
				label: { fr: 'Nord', en: 'North' },
				places: ['Villeray', 'Saint-Michel', 'Ahuntsic', 'Cartierville', 'Montréal-Nord', 'Saint-Laurent']
			},
			{
				label: { fr: 'Sud-Ouest', en: 'South-West' },
				places: ['Verdun', 'Île-des-Sœurs', 'LaSalle', 'Lachine']
			},
			{
				label: { fr: 'Ouest-de-l’Île', en: 'West Island' },
				places: [
					'Dorval',
					'Pointe-Claire',
					'Kirkland',
					'Dollard-des-Ormeaux',
					'Roxboro',
					'L’Île-Bizard',
					'Beaconsfield',
					'Sainte-Anne-de-Bellevue',
					'Senneville'
				]
			},
			{
				label: { fr: 'Vaudreuil-Soulanges, à l’ouest de l’île', en: 'Vaudreuil-Soulanges, west of the island' },
				places: ['L’Île-Perrot', 'Pincourt', 'Vaudreuil-Dorion']
			}
		],
		fr: {
			slug: 'montreal',
			name: 'Montréal',
			h1: 'Entretien ménager dans tous les arrondissements de Montréal',
			metaTitle: 'Entretien ménager par arrondissement, Montréal | Nett-Med',
			metaDescription:
				'Entretien ménager commercial et résidentiel dans tous les arrondissements de Montréal et l’Ouest-de-l’Île. Bureau rue Jarry. Soumission gratuite.',
			lede: 'Notre bureau est rue Jarry, dans Saint-Michel, au centre de l’île. Nous entretenons des immeubles, des bureaux, des commerces et des résidences dans tous les arrondissements, du Vieux-Montréal à l’Ouest-de-l’Île.',
			body: [
				'Le parc immobilier de l’île est varié, et le travail l’est aussi. Les immeubles d’appartements plus anciens ont souvent un hall en granit, en terrazzo ou en travertin, qu’un lavage régulier garde lustré sans l’abîmer. Les tours de bureaux et de condos du centre-ville ont presque toutes un garage souterrain qui accumule le calcium tout l’hiver.',
				'Pour les bureaux et les commerces, nous travaillons en soirée ou la nuit, une fois les locaux vides — ce qui évite du même coup la circulation des heures de pointe.'
			]
		},
		en: {
			slug: 'montreal',
			name: 'Montreal',
			h1: 'Cleaning services in every Montreal borough',
			metaTitle: 'Cleaning Services by Borough, Montreal | Nett-Med',
			metaDescription:
				'Commercial and residential cleaning in every Montreal borough and the West Island. Office on rue Jarry. Free quote.',
			lede: 'Our office is on rue Jarry in Saint-Michel, in the middle of the island. We maintain buildings, offices, retail spaces and homes in every borough, from Old Montreal to the West Island.',
			body: [
				'The island’s building stock is varied, and so is the work. Older apartment buildings often have a granite, terrazzo or travertine lobby that regular washing keeps glossy without damaging it. Downtown office and condo towers nearly all have an underground garage that collects calcium all winter.',
				'For offices and retail we work in the evening or overnight, once the space is empty — which also keeps us out of rush-hour traffic.'
			]
		}
	},

	{
		id: 'rive-nord',
		primary: ['Laval', 'Terrebonne', 'Repentigny', 'Blainville', 'Saint-Jérôme'],
		services: ['immeubles', 'garage', 'apres-construction', 'demenagement'],
		groups: [
			{
				label: { fr: 'Laval', en: 'Laval' },
				places: [
					'Chomedey',
					'Laval-des-Rapides',
					'Pont-Viau',
					'Duvernay',
					'Saint-Vincent-de-Paul',
					'Saint-François',
					'Vimont',
					'Auteuil',
					'Sainte-Rose',
					'Fabreville',
					'Laval-Ouest',
					'Sainte-Dorothée'
				]
			},
			{
				label: { fr: 'Lanaudière', en: 'Lanaudière' },
				places: ['Terrebonne', 'Lachenaie', 'La Plaine', 'Mascouche', 'Repentigny', 'Le Gardeur']
			},
			{
				label: { fr: 'Basses-Laurentides', en: 'Lower Laurentians' },
				places: [
					'Bois-des-Filion',
					'Lorraine',
					'Rosemère',
					'Boisbriand',
					'Sainte-Thérèse',
					'Blainville',
					'Mirabel',
					'Saint-Janvier',
					'Saint-Jérôme',
					'Saint-Antoine',
					'Bellefeuille',
					'Lafontaine',
					'Saint-Eustache',
					'Deux-Montagnes',
					'Sainte-Marthe-sur-le-Lac',
					'Oka'
				]
			}
		],
		fr: {
			slug: 'rive-nord',
			name: 'Rive-Nord',
			h1: 'Entretien ménager à Laval et sur la Rive-Nord',
			metaTitle: 'Entretien ménager Laval et Rive-Nord | Nett-Med',
			metaDescription:
				'Entretien ménager commercial et résidentiel à Laval, Terrebonne, Repentigny, Blainville et dans les Basses-Laurentides. Soumission gratuite.',
			lede: 'Nous desservons Laval et la couronne nord : Terrebonne, Mascouche et Repentigny dans Lanaudière, et les Basses-Laurentides jusqu’à Saint-Jérôme. Sur contrat ou pour des mandats ponctuels.',
			body: [
				'Laval concentre des tours de condos, des immeubles locatifs et des centres commerciaux, dont beaucoup ont un garage intérieur à laver chaque printemps. Plus au nord, Terrebonne, Mirabel et Blainville comptent de nombreux quartiers récents, où le nettoyage après construction et le ménage avant l’emménagement sont des demandes courantes.',
				'Pour les secteurs les plus éloignés, comme Saint-Jérôme ou Oka, la fréquence et les frais de déplacement éventuels sont précisés dans la soumission, avant tout engagement — pas découverts sur la facture.'
			]
		},
		en: {
			slug: 'north-shore',
			name: 'North Shore',
			h1: 'Cleaning services in Laval and on the North Shore',
			metaTitle: 'Cleaning Services Laval and North Shore | Nett-Med',
			metaDescription:
				'Commercial and residential cleaning in Laval, Terrebonne, Repentigny, Blainville and the Lower Laurentians. Free quote.',
			lede: 'We serve Laval and the north crown: Terrebonne, Mascouche and Repentigny in Lanaudière, and the Lower Laurentians as far as Saint-Jérôme. On contract or for one-time work.',
			body: [
				'Laval has a concentration of condo towers, rental buildings and shopping centres, many with an indoor garage to wash each spring. Further north, Terrebonne, Mirabel and Blainville have many newer neighbourhoods, where post-construction cleaning and move-in cleaning are common requests.',
				'For the outlying sectors, such as Saint-Jérôme or Oka, frequency and any travel charge are set out in the quote before anything is agreed — not discovered on the invoice.'
			]
		}
	},

	{
		id: 'rive-sud',
		primary: ['Longueuil', 'Brossard', 'Boucherville', 'Chambly', 'La Prairie'],
		services: ['immeubles', 'bureaux', 'garage', 'apres-construction'],
		groups: [
			{
				label: { fr: 'Agglomération de Longueuil', en: 'Longueuil agglomeration' },
				places: [
					'Longueuil',
					'Saint-Hubert',
					'Greenfield Park',
					'Brossard',
					'Saint-Lambert',
					'Boucherville',
					'Saint-Bruno-de-Montarville'
				]
			},
			{
				label: { fr: 'Marguerite-D’Youville', en: 'Marguerite-D’Youville' },
				places: ['Varennes', 'Sainte-Julie']
			},
			{
				label: { fr: 'Vallée-du-Richelieu', en: 'Richelieu Valley' },
				places: [
					'Saint-Basile-le-Grand',
					'Chambly',
					'Carignan',
					'Belœil',
					'McMasterville',
					'Otterburn Park',
					'Mont-Saint-Hilaire'
				]
			},
			{
				label: { fr: 'Roussillon', en: 'Roussillon' },
				places: ['La Prairie', 'Candiac', 'Saint-Constant', 'Delson', 'Sainte-Catherine']
			}
		],
		fr: {
			slug: 'rive-sud',
			name: 'Rive-Sud',
			h1: 'Entretien ménager à Longueuil et sur la Rive-Sud',
			metaTitle: 'Entretien ménager Longueuil et Rive-Sud | Nett-Med',
			metaDescription:
				'Entretien ménager commercial et résidentiel à Longueuil, Brossard, Boucherville, Chambly, La Prairie et sur toute la Rive-Sud. Soumission gratuite.',
			lede: 'Nous desservons l’agglomération de Longueuil — Longueuil, Brossard, Boucherville, Saint-Lambert, Saint-Bruno — ainsi que Varennes, Sainte-Julie, la Vallée-du-Richelieu et le secteur de La Prairie.',
			body: [
				'Brossard et Longueuil comptent de plus en plus de tours de condos et d’immeubles de bureaux, avec des halls, des ascenseurs et des garages intérieurs à entretenir sur contrat. Plus à l’est, Belœil, Chambly et Mont-Saint-Hilaire sont surtout résidentiels : grand ménage, ménage régulier et nettoyage après rénovation.',
				'Comme pour la Rive-Nord, les frais de déplacement éventuels vers les secteurs éloignés sont précisés dans la soumission, avant tout engagement.'
			]
		},
		en: {
			slug: 'south-shore',
			name: 'South Shore',
			h1: 'Cleaning services in Longueuil and on the South Shore',
			metaTitle: 'Cleaning Services Longueuil and South Shore | Nett-Med',
			metaDescription:
				'Commercial and residential cleaning in Longueuil, Brossard, Boucherville, Chambly, La Prairie and across the South Shore. Free quote.',
			lede: 'We serve the Longueuil agglomeration — Longueuil, Brossard, Boucherville, Saint-Lambert, Saint-Bruno — along with Varennes, Sainte-Julie, the Richelieu Valley and the La Prairie area.',
			body: [
				'Brossard and Longueuil have a growing number of condo towers and office buildings, with lobbies, elevators and indoor garages to maintain on contract. Further east, Belœil, Chambly and Mont-Saint-Hilaire are mostly residential: deep cleaning, regular housekeeping and post-renovation cleaning.',
				'As on the North Shore, any travel charge to outlying sectors is set out in the quote before anything is agreed.'
			]
		}
	}
];

/** Every place in a region, headline cities first, without duplicates. */
export function placesIn(region: Region): string[] {
	return [...new Set([...region.primary, ...region.groups.flatMap((g) => g.places)])];
}

export function getRegionBySlug(slug: string, locale: Locale): Region | undefined {
	return regions.find((r) => r[locale].slug === slug);
}

export const areasIndex: Record<
	Locale,
	{ metaTitle: string; metaDescription: string; h1: string; lede: string }
> = {
	fr: {
		metaTitle: 'Territoire desservi, Grand Montréal | Nett-Med',
		metaDescription:
			'Les secteurs desservis par Nett-Med : tous les arrondissements de Montréal, Laval et la Rive-Nord, Longueuil et la Rive-Sud, et Vaudreuil-Soulanges.',
		h1: 'Territoire desservi',
		lede: 'Montréal, Laval, la Rive-Nord et la Rive-Sud. Si votre municipalité ne figure pas ci-dessous, appelez-nous quand même : la liste n’est pas une frontière.'
	},
	en: {
		metaTitle: 'Service Area, Greater Montreal | Nett-Med',
		metaDescription:
			'Where Nett-Med works: every Montreal borough, Laval and the North Shore, Longueuil and the South Shore, and Vaudreuil-Soulanges.',
		h1: 'Service area',
		lede: 'Montreal, Laval, the North Shore and the South Shore. If your municipality is not listed below, call anyway — the list is not a boundary.'
	}
};
