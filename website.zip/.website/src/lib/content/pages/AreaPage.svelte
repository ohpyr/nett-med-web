<script lang="ts">
	import QuoteBand from '$lib/components/QuoteBand.svelte';
	import Seo from '$lib/components/Seo.svelte';
	import ServiceRows from '$lib/components/ServiceRows.svelte';
	import { SITE_URL, business } from '$lib/config';
	import { getService, type LocalizedService } from '$lib/content';
	import { placesIn, regions, type Region } from '$lib/content/areas';
	import { routes, t, type Locale } from '$lib/i18n';
	import { areaServiceSchema, breadcrumbSchema } from '$lib/schema';

	interface Props {
		locale: Locale;
		altPath: string;
		region: Region;
	}

	let { locale, altPath, region }: Props = $props();

	const s = $derived(t[locale]);
	const c = $derived(region[locale]);
	const path = $derived(`${routes.areas[locale]}/${c.slug}`);
	const services = $derived(
		region.services
			.map((id) => getService(id, locale))
			.filter((x): x is LocalizedService => x !== undefined)
	);
	/* The other two regions, so a visitor on the wrong page is one click away. */
	const others = $derived(regions.filter((r) => r.id !== region.id));

	const crumbs = $derived([
		{ name: s.labels.breadcrumbHome, url: routes.home[locale] },
		{ name: s.labels.serviceArea, url: routes.areas[locale] },
		{ name: c.name, url: path }
	]);
</script>

<Seo
	{locale}
	title={c.metaTitle}
	description={c.metaDescription}
	{path}
	{altPath}
	schemas={[
		areaServiceSchema(c.h1, c.metaDescription, placesIn(region), `${SITE_URL}${path}`, locale),
		breadcrumbSchema(crumbs)
	]}
/>

<header class="shell pt-10 pb-section">
	<nav aria-label={s.labels.serviceArea} class="text-sm text-muted">
		<ol class="flex flex-wrap items-center gap-2">
			{#each crumbs as crumb, i}
				<li class="flex items-center gap-2">
					{#if i < crumbs.length - 1}
						<a href={crumb.url} class="hover:text-blue">{crumb.name}</a>
						<span aria-hidden="true" class="text-rule">/</span>
					{:else}
						<span aria-current="page">{crumb.name}</span>
					{/if}
				</li>
			{/each}
		</ol>
	</nav>

	<div class={region.photo ? 'mt-7 grid gap-10 lg:grid-cols-[1fr_minmax(0,24rem)] lg:items-start' : 'mt-7'}>
		<div>
			<h1 class="max-w-3xl text-h1 font-semibold">{c.h1}</h1>
			<p class="measure mt-6 text-lead text-muted">{c.lede}</p>
			<div class="measure mt-6 space-y-4 text-muted">
				{#each c.body as paragraph}
					<p>{paragraph}</p>
				{/each}
			</div>
			<div class="mt-9 flex flex-col gap-3 sm:flex-row">
				<a
					href={routes.quote[locale]}
					class="bg-blue px-6 py-3.5 text-center font-semibold text-white transition-colors hover:bg-ink"
				>
					{s.cta.quote}
				</a>
				<a
					href="tel:{business.phoneHref}"
					class="border border-rule px-6 py-3.5 text-center font-semibold text-ink tabular-nums transition-colors hover:border-blue hover:text-blue"
				>
					{business.phone}
				</a>
			</div>
		</div>

		{#if region.photo}
			<enhanced:img
				src={region.photo.src}
				alt={region.photo.alt[locale]}
				sizes="(min-width: 1024px) 24rem, 88vw"
				fetchpriority="high"
				class="aspect-4/5 w-full object-cover"
			/>
		{/if}
	</div>
</header>

<section class="bg-paper-tint">
	<div class="shell py-section">
		<h2 class="text-h2 font-semibold">{s.labels.municipalities}</h2>
		<div class="row-list mt-9">
			{#each region.groups as group}
				<div class="grid gap-2 py-6 md:grid-cols-[minmax(0,17rem)_1fr] md:gap-8">
					<h3 class="text-h3 font-semibold">{group.label[locale]}</h3>
					<p class="text-muted">{group.places.join(' · ')}</p>
				</div>
			{/each}
		</div>
	</div>
</section>

<section class="shell py-section">
	<h2 class="text-h2 font-semibold">{s.labels.servicesHere}</h2>
	<div class="mt-9 rule-top">
		<ServiceRows {locale} items={services} />
	</div>

	<p class="mt-10 text-sm text-muted">
		{#each others as other, i}
			<a href="{routes.areas[locale]}/{other[locale].slug}" class="font-semibold text-blue hover:underline">
				{other[locale].name}
			</a>{i < others.length - 1 ? ' · ' : ''}
		{/each}
		· <a href={routes.areas[locale]} class="font-semibold text-blue hover:underline">{s.labels.allAreas}</a>
	</p>
</section>

<QuoteBand {locale} />
