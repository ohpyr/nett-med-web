<script lang="ts">
	import QuoteBand from '$lib/components/QuoteBand.svelte';
	import RegionLinks from '$lib/components/RegionLinks.svelte';
	import Seo from '$lib/components/Seo.svelte';
	import ServiceRows from '$lib/components/ServiceRows.svelte';
	import { business, testimonials } from '$lib/config';
	import { photos } from '$lib/content/media';
	import { pillarService, servicesInPillar } from '$lib/content';
	import { home } from '$lib/content/pages';
	import { routes, servicePath, t, type Locale } from '$lib/i18n';
	import { localBusinessSchema, webSiteSchema } from '$lib/schema';

	interface Props {
		locale: Locale;
		altPath: string;
	}

	let { locale, altPath }: Props = $props();

	const c = $derived(home[locale]);
	const heroPhoto = photos.hallGranitIncrustation;
	/* Commercial first, matching the page; none repeats the hero image. */
	const workStrip = [
		photos.hallTravertinEntree,
		photos.restaurantBois,
		photos.salonCoiffure,
		photos.appartement
	];
	const s = $derived(t[locale]);
	const commercialPillar = $derived(pillarService('commercial', locale));
	const residentialPillar = $derived(pillarService('residential', locale));
	const commercial = $derived(servicesInPillar('commercial', locale));
	const residential = $derived(servicesInPillar('residential', locale));
	const specialized = $derived(servicesInPillar('specialized', locale));
</script>

<Seo
	{locale}
	title={c.metaTitle}
	description={c.metaDescription}
	path={routes.home[locale]}
	{altPath}
	schemas={[localBusinessSchema(locale), webSiteSchema(locale)]}
/>

<!-- Hero. Acquire’s formula: say literally what the business is, for whom and
     where, then one CTA, then hard numbers. The photo is one of Nett-Med’s own
     jobs — a lobby it maintains — not stock: a real result is the strongest
     trust signal the page can show, and a stock photo of smiling cleaners
     would undo it. -->
<section class="bg-ink text-white">
	<div class="shell grid gap-12 pt-section-lg pb-section lg:grid-cols-[1fr_minmax(0,26rem)] lg:items-center lg:gap-16">
		<div>
			<div class="h-0.5 w-16 bg-green-bright" aria-hidden="true"></div>

			<h1 class="mt-8 max-w-4xl text-display font-semibold">
				{c.h1}
			</h1>

			<p class="mt-7 max-w-2xl text-lead text-white/75">
				{c.lede}
			</p>

			<div class="mt-10 flex flex-col gap-3 sm:flex-row">
				<a
					href={routes.quote[locale]}
					class="bg-white px-7 py-4 text-center font-semibold text-ink transition-colors hover:bg-green-bright"
				>
					{s.cta.quote}
				</a>
				<a
					href="tel:{business.phoneHref}"
					class="border border-white/30 px-7 py-4 text-center font-semibold text-white tabular-nums transition-colors hover:bg-white/10"
				>
					{business.phone}
				</a>
			</div>
		</div>

		<!-- Above the fold on desktop, so it is the LCP element there: loaded
		     eagerly at high priority rather than lazily. -->
		<figure>
			<enhanced:img
				src={heroPhoto.src}
				alt={heroPhoto.alt[locale]}
				sizes="(min-width: 1024px) 26rem, 88vw"
				fetchpriority="high"
				class="aspect-4/5 w-full object-cover"
			/>
			<figcaption class="mt-3 text-xs text-muted-dark">{c.heroCaption}</figcaption>
		</figure>
	</div>

	<div class="shell">
		<dl class="rule-top-dark grid grid-cols-2 gap-x-6 gap-y-8 py-9 lg:grid-cols-4">
			{#each c.facts as fact}
				<div>
					<dt class="text-h3 font-semibold text-white">{fact.value}</dt>
					<dd class="mt-1 text-sm text-muted-dark">{fact.label}</dd>
				</div>
			{/each}
		</dl>
	</div>
</section>

<!-- Commercial first, deliberately: it is the stated business priority and the
     higher-value contract. -->
<section class="shell py-section">
	<div class="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
		<h2 class="text-h2 font-semibold">{c.commercialHeading}</h2>
		<a
			href={commercialPillar ? servicePath(locale, commercialPillar.slug) : routes.services[locale]}
			class="text-sm font-semibold text-blue hover:underline"
		>
			{commercialPillar?.navLabel} →
		</a>
	</div>
	<p class="measure mt-4 text-muted">{c.commercialIntro}</p>

	<div class="mt-10 rule-top">
		<ServiceRows {locale} items={commercial} />
	</div>
</section>

<section class="bg-paper-tint">
	<div class="shell py-section">
		<div class="grid gap-8 lg:grid-cols-[minmax(0,26rem)_1fr] lg:gap-16">
			<h2 class="text-h2 font-semibold">{c.angle.heading}</h2>
			<div class="measure space-y-5 text-muted">
				{#each c.angle.body as paragraph}
					<p>{paragraph}</p>
				{/each}
			</div>
		</div>
	</div>
</section>

<section class="shell py-section">
	<div class="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
		<h2 class="text-h2 font-semibold">{c.residentialHeading}</h2>
		<a
			href={residentialPillar
				? servicePath(locale, residentialPillar.slug)
				: routes.services[locale]}
			class="text-sm font-semibold text-blue hover:underline"
		>
			{residentialPillar?.navLabel} →
		</a>
	</div>
	<p class="measure mt-4 text-muted">{c.residentialIntro}</p>

	<div class="mt-10 rule-top">
		<ServiceRows {locale} items={residential} />
	</div>
</section>

<section class="shell pb-section">
	<h2 class="text-h2 font-semibold">{s.sections.specializedServices}</h2>
	<div class="mt-10 rule-top">
		<ServiceRows {locale} items={specialized} />
	</div>
</section>

<!-- A strip of real job photos, placed before the testimonials so the claims
     that follow have evidence ahead of them. Lazy-loaded: it is well below the
     fold. -->
<section class="shell pb-section">
	<div class="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
		<h2 class="text-h2 font-semibold">{c.workHeading}</h2>
		<a href={routes.work[locale]} class="text-sm font-semibold text-blue hover:underline">
			{s.nav.work} →
		</a>
	</div>
	<p class="measure mt-4 text-muted">{c.workIntro}</p>

	<div class="-mx-[6vw] mt-10 flex snap-x gap-3 overflow-x-auto px-[6vw] lg:mx-0 lg:grid lg:grid-cols-4 lg:px-0">
		{#each workStrip as photo}
			<enhanced:img
				src={photo.src}
				alt={photo.alt[locale]}
				sizes="(min-width: 1024px) 18rem, 60vw"
				loading="lazy"
				decoding="async"
				class="aspect-3/4 h-80 w-auto shrink-0 snap-start object-cover lg:h-auto lg:w-full"
			/>
		{/each}
	</div>
</section>

<!-- Named quotes, not a star widget. The review profile is three positive and
     two negative; an aggregate rating would read as roughly 3.4 stars and cost
     more than it earns. See docs/seo/SEO-STRATEGY.md. -->
<section class="bg-paper-tint">
	<div class="shell py-section">
		<h2 class="text-h2 font-semibold">{c.testimonialsHeading}</h2>
		<div class="row-list mt-10">
			{#each testimonials as item (item.id)}
				<figure class="grid gap-4 py-8 md:grid-cols-[1fr_minmax(0,14rem)] md:gap-10">
					<blockquote class="text-lead text-ink">
						{item.quote[locale]}
					</blockquote>
					<figcaption class="text-sm text-muted">
						<span class="font-semibold text-ink">{item.author}</span><br />
						{item.role[locale]}
						<!-- Every review was written in French. Saying so on the English
						     page keeps the quote from reading as the customer's own
						     English words. -->
						{#if item.sourceLocale !== locale}
							<br /><span class="text-xs">{s.labels.translatedFrom}</span>
						{/if}
					</figcaption>
				</figure>
			{/each}
		</div>
	</div>
</section>

<section class="shell py-section">
	<h2 class="text-h2 font-semibold">{c.areaHeading}</h2>
	<p class="measure mt-4 text-muted">{c.areaBody}</p>
	<div class="mt-8">
		<RegionLinks {locale} />
	</div>
</section>

<QuoteBand {locale} />
