<script lang="ts">
	import QuoteBand from '$lib/components/QuoteBand.svelte';
	import Seo from '$lib/components/Seo.svelte';
	import { areasIndex, regions } from '$lib/content/areas';
	import { routes, t, type Locale } from '$lib/i18n';
	import { breadcrumbSchema } from '$lib/schema';

	interface Props {
		locale: Locale;
		altPath: string;
	}

	let { locale, altPath }: Props = $props();

	const c = $derived(areasIndex[locale]);
	const s = $derived(t[locale]);
</script>

<Seo
	{locale}
	title={c.metaTitle}
	description={c.metaDescription}
	path={routes.areas[locale]}
	{altPath}
	schemas={[
		breadcrumbSchema([
			{ name: s.labels.breadcrumbHome, url: routes.home[locale] },
			{ name: s.labels.serviceArea, url: routes.areas[locale] }
		])
	]}
/>

<header class="shell pt-12 pb-section">
	<h1 class="max-w-3xl text-h1 font-semibold">{c.h1}</h1>
	<p class="measure mt-6 text-lead text-muted">{c.lede}</p>
</header>

{#each regions as region, i (region.id)}
	<section class={i % 2 === 0 ? 'bg-paper-tint' : ''}>
		<div class="shell py-section">
			<div class="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
				<h2 class="text-h2 font-semibold">
					<a href="{routes.areas[locale]}/{region[locale].slug}" class="hover:text-blue">
						{region[locale].name}
					</a>
				</h2>
				<a
					href="{routes.areas[locale]}/{region[locale].slug}"
					class="text-sm font-semibold text-blue hover:underline"
				>
					{region[locale].h1} →
				</a>
			</div>
			<div class="row-list mt-8">
				{#each region.groups as group}
					<div class="grid gap-2 py-5 md:grid-cols-[minmax(0,17rem)_1fr] md:gap-8">
						<h3 class="font-semibold">{group.label[locale]}</h3>
						<p class="text-muted">{group.places.join(' · ')}</p>
					</div>
				{/each}
			</div>
		</div>
	</section>
{/each}

<QuoteBand {locale} />
