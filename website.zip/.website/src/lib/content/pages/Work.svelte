<script lang="ts">
	import QuoteBand from '$lib/components/QuoteBand.svelte';
	import Seo from '$lib/components/Seo.svelte';
	import { getService } from '$lib/content';
	import { work } from '$lib/content/pages';
	import { restaurantVideo } from '$lib/content/media';
	import { jobs } from '$lib/content/work';
	import { routes, servicePath, t, type Locale } from '$lib/i18n';
	import { breadcrumbSchema } from '$lib/schema';

	interface Props {
		locale: Locale;
		altPath: string;
	}

	let { locale, altPath }: Props = $props();

	const c = $derived(work[locale]);
	const s = $derived(t[locale]);
</script>

<Seo
	{locale}
	title={c.metaTitle}
	description={c.metaDescription}
	path={routes.work[locale]}
	{altPath}
	schemas={[
		breadcrumbSchema([
			{ name: s.labels.breadcrumbHome, url: routes.home[locale] },
			{ name: s.nav.work, url: routes.work[locale] }
		])
	]}
/>

<header class="shell pt-12 pb-section">
	<h1 class="max-w-3xl text-h1 font-semibold">{c.h1}</h1>
	<p class="measure mt-6 text-lead text-muted">{c.lede}</p>
</header>

<section class="shell pb-section">
	<div class="row-list rule-top">
		{#each jobs as job (job.id)}
			{@const service = getService(job.serviceId, locale)}
			<!-- Text on the left, the job's photos as a strip on the right. Every
			     tile is the same height with its width set by aspect ratio, so a
			     row of 3:4 photos and a 9:16 video line up without cropping the
			     video. On narrow screens the strip scrolls sideways rather than
			     shrinking the photos to thumbnails. -->
			<article class="grid gap-6 py-10 lg:grid-cols-[minmax(0,20rem)_1fr] lg:gap-10">
				<div>
					<h2 class="text-h3 font-semibold">{job.title[locale]}</h2>
					{#if job.location}
						<p class="mt-1 text-sm text-muted">{job.location}</p>
					{/if}
					<p class="mt-4 text-muted">{job.scope[locale]}</p>
					{#if service}
						<a
							href={servicePath(locale, service.slug)}
							class="mt-4 inline-block text-sm font-semibold text-blue hover:underline"
						>
							{service.navLabel} →
						</a>
					{/if}
				</div>

				<div class="-mx-[6vw] flex snap-x gap-3 overflow-x-auto px-[6vw] lg:mx-0 lg:px-0">
					{#each job.media as photo}
						<enhanced:img
							src={photo.src}
							alt={photo.alt[locale]}
							sizes="(min-width: 1024px) 15rem, 60vw"
							loading="lazy"
							decoding="async"
							class="aspect-3/4 h-80 w-auto shrink-0 snap-start object-cover"
						/>
					{/each}
					{#if job.video}
						<!-- No autoplay: motion the visitor did not ask for is exactly
						     the kind of distraction this site avoids. The clip is
						     silent — the audio track was ambient noise and was
						     stripped when it was encoded. -->
						<video
							controls
							muted
							playsinline
							preload="none"
							poster={restaurantVideo.poster}
							width={restaurantVideo.width}
							height={restaurantVideo.height}
							aria-label={restaurantVideo.label[locale]}
							class="aspect-9/16 h-80 w-auto shrink-0 snap-start bg-ink object-cover"
						>
							<source src={restaurantVideo.webm} type="video/webm" />
							<source src={restaurantVideo.mp4} type="video/mp4" />
						</video>
					{/if}
				</div>
			</article>
		{/each}
	</div>
</section>

<QuoteBand {locale} />
