import type { Locale } from '$lib/i18n';
import { photos, type Photo } from './media';

/*
  The Réalisations gallery.

  A job can carry several photos, and the restaurant job also shows the video.
  Photos of the same space are grouped instead of listed as separate jobs, so
  the page reads as a set of real jobs rather than a stream of near-duplicates.

  TODO(client): the borough is known only for the Côte-des-Neiges building.
  Fill in `location` for the others when you can — a named neighbourhood is
  more convincing to a nearby buyer than a photo alone. Also confirm two
  categories inferred from the photos: `clinique` (could be a salon or
  med-spa) and `cuisine-reno` (could be a deep clean rather than a handover).
*/

export interface Job {
	id: string;
	media: Photo[];
	/** Show the restaurant video alongside the photos. */
	video?: boolean;
	title: Record<Locale, string>;
	/** null until the real borough is known — never render a placeholder. */
	location: string | null;
	scope: Record<Locale, string>;
	/** id of the related service page, for internal linking. */
	serviceId: string;
}

/* Commercial first, matching the site's stated priority. */
export const jobs: Job[] = [
	{
		id: 'halls-granit',
		media: [photos.hallGranitIncrustation, photos.hallGranitPortes, photos.hallGranitLaiton],
		title: { fr: 'Halls d’immeubles en granit', en: 'Granite building lobbies' },
		location: null,
		scope: {
			fr: 'Entretien des halls d’entrée : planchers de granit lavés jusqu’au lustre, vitres et cadres de porte, plinthes et seuils.',
			en: 'Lobby maintenance: granite floors washed to a shine, door glass and frames, baseboards and thresholds.'
		},
		serviceId: 'immeubles'
	},
	{
		id: 'hall-travertin',
		media: [photos.hallTravertinEntree, photos.hallTravertinVue],
		title: { fr: 'Hall d’immeuble en travertin', en: 'Travertine building lobby' },
		location: null,
		scope: {
			fr: 'Hall et vestibule d’un immeuble résidentiel : plancher de travertin, entrée vitrée, tapis d’entrée et mobilier.',
			en: 'Lobby and vestibule of a residential building: travertine floor, glass entrance, entry mats and furniture.'
		},
		serviceId: 'immeubles'
	},
	{
		id: 'immeuble-cdn',
		media: [photos.corridorResidentiel],
		title: { fr: 'Immeuble résidentiel', en: 'Residential building' },
		location: 'Côte-des-Neiges, Montréal',
		scope: {
			fr: 'Nettoyage en profondeur des parties communes d’un immeuble de quatre étages : corridors, entrée, plancher de terrazzo et tapis d’entrée.',
			en: 'Deep clean of the common areas of a four-storey building: corridors, entrance, terrazzo floor and entrance matting.'
		},
		serviceId: 'immeubles'
	},
	{
		id: 'entree-commerciale',
		media: [photos.entreeCommerciale],
		title: { fr: 'Entrée d’immeuble commercial', en: 'Commercial building entrance' },
		location: null,
		scope: {
			fr: 'Entretien de l’entrée et du vestibule : plancher de tuile, portes vitrées et zone d’accueil.',
			en: 'Entrance and vestibule maintenance: tile floor, glass doors and reception area.'
		},
		serviceId: 'commercial'
	},
	{
		id: 'clinique',
		media: [photos.corridorClinique],
		title: { fr: 'Clinique privée', en: 'Private clinic' },
		location: null,
		scope: {
			fr: 'Entretien du corridor et des salles de traitement : plancher de tuile, cloisons vitrées sans traces et points de contact désinfectés.',
			en: 'Corridor and treatment room maintenance: tile floor, streak-free glass partitions and disinfected touch points.'
		},
		serviceId: 'cliniques'
	},
	{
		id: 'restaurant',
		media: [photos.restaurantBois, photos.restaurantBlanc],
		video: true,
		title: { fr: 'Restaurant', en: 'Restaurant' },
		location: null,
		scope: {
			fr: 'Entretien de nuit après la fermeture : planchers des deux salles, tables et banquettes, et dépoussiérage en hauteur du plafond et des luminaires.',
			en: 'Overnight cleaning after closing: floors in both dining rooms, tables and banquettes, and high dusting of the ceiling and light fixtures.'
		},
		serviceId: 'restaurants'
	},
	{
		id: 'salon-coiffure',
		media: [photos.salonCoiffure],
		title: { fr: 'Salon de coiffure', en: 'Hair salon' },
		location: null,
		scope: {
			fr: 'Entretien du plancher de vente et des postes de travail, avant l’ouverture.',
			en: 'Sales floor and styling stations cleaned before opening.'
		},
		serviceId: 'commerces'
	},
	{
		id: 'cuisine-reno',
		media: [photos.cuisineReno],
		title: { fr: 'Cuisine après rénovation', en: 'Kitchen after renovation' },
		location: null,
		scope: {
			fr: 'Nettoyage de livraison d’une cuisine neuve : intérieur et extérieur des armoires, îlot de quartz, électroménagers et planchers.',
			en: 'Handover clean of a new kitchen: cabinet interiors and exteriors, quartz island, appliances and floors.'
		},
		serviceId: 'apres-construction'
	},
	{
		id: 'appartement',
		media: [photos.appartement],
		title: { fr: 'Appartement', en: 'Apartment' },
		location: null,
		scope: {
			fr: 'Grand ménage d’un appartement : planchers de bois franc, aires de vie, salle à manger et cuisine ouverte.',
			en: 'Deep clean of an apartment: hardwood floors, living areas, dining room and open kitchen.'
		},
		serviceId: 'grand-menage'
	},
	{
		id: 'cuisine-residentielle',
		media: [photos.cuisineResidentielle],
		title: { fr: 'Cuisine résidentielle', en: 'Residential kitchen' },
		location: null,
		scope: {
			fr: 'Ménage régulier d’une résidence : comptoirs, électroménagers, dosseret et plancher de céramique.',
			en: 'Regular home cleaning: counters, appliances, backsplash and tile floor.'
		},
		serviceId: 'residentiel'
	},
	{
		id: 'logement-vide',
		media: [photos.logementVide],
		title: { fr: 'Logement entre deux locataires', en: 'Unit between tenants' },
		location: null,
		scope: {
			fr: 'Ménage complet d’un logement vide avant l’emménagement : planchers de bois franc, fenêtres, plinthes et cadrages.',
			en: 'Full clean of an empty unit before move-in: hardwood floors, windows, baseboards and frames.'
		},
		serviceId: 'demenagement'
	}
];
