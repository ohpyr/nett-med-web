<script lang="ts">
	import { regions } from '$lib/content/areas';
	import { routes, t, type Locale } from '$lib/i18n';

	interface Props {
		locale: Locale;
	}

	let { locale }: Props = $props();

	const s = $derived(t[locale]);
</script>

<!-- The three regions as rows, each linking to its page. Replaces a flat list
     of town names, which gave a visitor nothing to click and a crawler no path
     to the regional pages. -->
<ul class="row-list rule-top">
	{#each regions as region (region.id)}
		<li>
			<a
				href="{routes.areas[locale]}/{region[locale].slug}"
				class="group grid gap-1.5 py-6 md:grid-cols-[minmax(0,17rem)_1fr] md:items-baseline md:gap-8"
			>
				<span class="text-h3 font-semibold transition-colors group-hover:text-blue">
					{region[locale].name}
				</span>
				<span class="text-muted">
					{region.groups.map((g) => g.label[locale]).join(' · ')}
				</span>
			</a>
		</li>
	{/each}
</ul>
<a href={routes.areas[locale]} class="mt-6 inline-block text-sm font-semibold text-blue hover:underline">
	{s.labels.allAreas} →
</a>
