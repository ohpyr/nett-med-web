import { getRegionBySlug, regions } from '$lib/content/areas';
import { error } from '@sveltejs/kit';
import type { EntryGenerator, PageLoad } from './$types';

export const entries: EntryGenerator = () => regions.map((r) => ({ slug: r.fr.slug }));

export const load: PageLoad = ({ params }) => {
	const region = getRegionBySlug(params.slug, 'fr');
	if (!region) error(404, 'Secteur introuvable');
	return { region };
};
