<script lang="ts">
	import AreasIndex from '$lib/content/pages/AreasIndex.svelte';

	let { data } = $props();
</script>

<AreasIndex locale={data.locale} altPath={data.altPath} />
