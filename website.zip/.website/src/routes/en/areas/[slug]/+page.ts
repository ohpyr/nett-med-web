import { getRegionBySlug, regions } from '$lib/content/areas';
import { error } from '@sveltejs/kit';
import type { EntryGenerator, PageLoad } from './$types';

export const entries: EntryGenerator = () => regions.map((r) => ({ slug: r.en.slug }));

export const load: PageLoad = ({ params }) => {
	const region = getRegionBySlug(params.slug, 'en');
	if (!region) error(404, 'Area not found');
	return { region };
};
