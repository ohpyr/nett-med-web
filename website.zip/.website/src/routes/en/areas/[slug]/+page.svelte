<script lang="ts">
	import AreaPage from '$lib/content/pages/AreaPage.svelte';

	let { data } = $props();
</script>

<AreaPage locale={data.locale} altPath={data.altPath} region={data.region} />
