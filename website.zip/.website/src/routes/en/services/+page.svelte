<script lang="ts">
	import ServicesIndex from '$lib/content/pages/ServicesIndex.svelte';

	let { data } = $props();
</script>

<ServicesIndex locale={data.locale} altPath={data.altPath} />
