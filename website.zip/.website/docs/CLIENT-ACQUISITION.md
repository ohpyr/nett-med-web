# Where clients actually come from

Researched October 2026, comparing Nett-Med with Entretien Simo-Pro.

## The short answer

**Simo-Pro's website is not why Simo-Pro gets clients.** It is a dated
WordPress theme with stock photos of smiling cleaners, typos in place names,
two different street addresses and two different emails on the same page, and
footer links that go nowhere. Its Facebook page has 13 likes. I found no
customer reviews for it anywhere.

A website does not generate clients for a cleaning company. It **converts**
people that something else sent. Nett-Med now has a better converting site
than Simo-Pro — but if nothing is sending people to it, it converts nothing.

## What Simo-Pro has that Nett-Med does not

**1. It is a franchise network.** simo-pro.ca sells franchises, promising
franchisees "a recognized brand" and marketing support. In public listings
the brand shows up with at least three addresses (Saint-Laurent, Montréal-Nord
on boulevard Saint-Michel, boulevard Deguire) and two phone numbers. That
means several people are prospecting under one name at the same time. This is
the most likely explanation I can see: more people actively selling, not a
better website.

**2. More presence across directories.** Each franchise location gets its own
directory listing (AnuGo and others), so the brand appears more often.

**3. Regional pages and a long list of areas served.** Simo-Pro has a
dedicated Rive-Sud page, and its own site appears in search results for its
service and regional pages. Nett-Med now has the same, done better — see below.

**What I could not verify:** whether Simo-Pro pays for Google Ads or for leads
on marketplace sites, and what its Google Business Profile looks like. Those
are the usual drivers in this trade, and they are invisible from outside.

## The channels that actually produce cleaning clients

Ordered by how fast they produce a signed client, not by how cheap they are.

### 1. Direct outreach to building buyers — fastest for contracts

The commercial building contract — the client Nett-Med most wants — is almost
never found through a Google search. A syndicate board or a property manager
signs with someone who contacted them, or someone another manager recommended.

- **Property management firms** (*gestionnaires immobiliers*). Each manages
  dozens of buildings. One relationship can mean several contracts. List the
  firms active in your sectors and call them.
- **Condo syndicates.** The RGCQ (Regroupement des gestionnaires et
  copropriétaires du Québec) is the main association for syndicates and
  managers in Québec; check whether it runs a supplier directory you can join.
- **Walk-in prospecting.** Visit buildings near jobs you already have, with a
  one-page sheet and photos of a lobby you maintain. The "Obligations du
  syndicat" article on the site exists to be printed and left behind.
- **Public tenders.** Schools, CPEs, municipal buildings and health facilities
  buy cleaning through calls for tenders on SEAO, Québec's public tendering
  system. Smaller contracts are within reach of a company your size.

### 2. Google Business Profile — the map results

When someone searches "entretien ménager près de moi", the map results with
three businesses get most of the clicks, above the regular results. That spot
comes from the Google Business Profile, not the website.

- Verify the profile (video verification is now standard).
- Primary category: commercial cleaning service. Add house cleaning as a
  secondary category.
- **Service areas:** paste the 20 municipalities in `business.areaServed` in
  `src/lib/config.ts`. Twenty is Google's maximum, and that list was chosen to
  fit it.
- **Upload the 15 job photos.** They are ready; profiles with recent photos
  get noticeably more engagement.
- Post once a week — a finished job, a photo, two lines.
- Make sure the phone number is exactly **(514) 218-7341** everywhere: the
  profile, Facebook, PagesJaunes, any directory. Mismatched numbers across the
  web weaken the map ranking.
- Then paste the profile URL into `business.sameAs` in `src/lib/config.ts` so
  the site and the profile are linked.

### 3. Reviews

Five reviews, two of them negative, is the single weakest point. Competitors
show hundreds.

- Ask every satisfied client, in person, the day the job finishes. Send the
  direct review link by text right after. Most reviews come from being asked,
  not from people volunteering.
- Reply publicly and calmly to both negative reviews. A professional reply is
  read by every future client, more than the review itself.
- Target: 20 reviews in three months. At that point the star rating can go on
  the website too — see `docs/seo/SEO-STRATEGY.md`.

### 4. Lead marketplaces — paid, but immediate

Sites where people request quotes and cleaning companies pay for the lead:
quote-comparison sites ("soumissions"), HomeStars, Bark, plus Kijiji and the
Facebook Marketplace services section. Many small Québec cleaning companies get
most of their residential work this way.

Start with one, track cost per signed client for a month, and keep it only if
the numbers work. Leads from these sites usually go to several companies at
once, so call back within the hour or lose it.

### 5. Google Ads

Search ads for "entretien ménager commercial Montréal" put you on the first
page from the first day — and stop the moment you stop paying. Worth testing
with a small fixed monthly budget once the profile and reviews are in place,
not before: an ad that leads to a profile with five reviews wastes money.

Check whether Google's Local Services Ads ("Google Screened") are available for
cleaning in your area — they charge per lead rather than per click.

### 6. The website and search rankings — slowest, but it compounds

This is the part already built. It takes **three to six months** for a site to
rank on competitive terms, longer against competitors with fifteen years of
history. In the meantime the site's job is to turn the visitors the channels
above send into quote requests, which it now does.

To speed it up:

- **Add the site to Google Search Console** and submit
  `https://nett-med.ca/sitemap.xml`. Without this, Google discovers pages slowly.
- Publish one article a month from the list in `docs/seo/ROADMAP.md`.
- Get listed in local directories with the exact same name, address and phone.

## A realistic first month

| Week | Do this |
|---|---|
| 1 | Verify the Google Business Profile, upload the photos, set the 20 service areas. Add the site to Search Console. Reply to the two negative reviews. |
| 2 | Ask every current client for a review. List 30 property management firms and syndicates in your sectors. |
| 3 | Call or visit the list from week 2. Sign up for one lead marketplace. |
| 4 | Look at what worked. Keep it, drop what didn't. |

The website is ready for all of this. The work that brings clients now is
outside it.
